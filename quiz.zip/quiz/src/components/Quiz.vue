<template>
    <div class="panel panel-default">

        <h1> Trello Project 188</h1> 
    </div>
</template>

<script>


    // export anonymous object from this module so it can be accessed by others when imported
    export default {
        name: 'Quiz',
        // these values will be filled in by parent component, values must match tag's attribute names
        props: [
            'quizdata'
        ]
    }
</script>