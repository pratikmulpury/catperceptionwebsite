<template>
  <div id="app">
    <div  v-show="!quizSelected">
      <H1> Choose A Quiz Based on your Personality</H1>
      <button  v-on:click="changeQuizSelection(1)" > (Computer Science Quiz) </button>
      <button  v-on:click="changeQuizSelection(2)"> (Math Quiz) </button>
      <button  v-on:click="changeQuizSelection(3)"> (Tennis Quiz) </button>
    </div>
        <local-quiz v-show="quizSelected"  }" > </local-quiz>
    </div>
  </div>
</template>

<script>

  import quiz from './components/Quiz.vue';


  export default {
    components:{
      'local-quiz': quiz
    },

    data () {
        return {
              myComponent : 'local-home',
              quizSelected: false,
              quizSelection: 0
            }
    },
    methods: {
      changeQuizSelection: function(index)
      {
        this.quizSelection = index;
        this.quizSelected = !this.quizSelected;
      }

    }  
  }
</script>
































<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}
</style>
